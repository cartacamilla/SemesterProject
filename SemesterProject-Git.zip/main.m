clc 
close all
clear 
%%

video_processing('Videos\WIN_20180312_14_01_50_Pro.mp4', 'result1.avi');